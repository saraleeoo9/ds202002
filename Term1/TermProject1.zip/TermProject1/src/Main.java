import java.util.Random;
import java.util.Scanner; 

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("N �Է� : ");
		int size = sc.nextInt();
		int max, min, total; 
		
		int[] arr = new int[size];
		
		Random rand = new Random();
		for(int i = 0; i<size; i++) {
			arr[i] = rand.nextInt(100)+1; 
			System.out.print(arr[i]+" ");
		}
		max = arr[0];
		min = arr[0];
		
		for(int i = 1; i<arr.length; i++) {
			if(max<arr[i])
				max = arr[i];
			if(min>arr[i])
				min = arr[i];
		}
		total = max + min;
		
		System.out.println();
		System.out.println("�ּҰ� + �ִ밪 �հ� = "+ total );
		
		
 
	}

}
